package org.example;

public class Output2 {
    public static void main(String[] args) {
        System.out.println("+++\n!!!!\n??");
    }
}
